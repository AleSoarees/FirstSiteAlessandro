package monetario;

public class Dolar extends Moeda {
	
	
	// - tipo: string identificando o tipo de moeda
    public Dolar(double valor, String tipo) {
        super(valor, tipo);
    }


    @Override
    double converter() {
    	
    	 // Conversão de dolar para real (1 dolar = 5,76 reais)
        return getValor() * 5.76;
    }
    
    
 // Método que retorna uma representação em string do objeto Dolar
	@Override
	public String toString() {
		return "Dolar [converter()=" + converter() + ", Valor()=" + getValor() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	// Método que gera um código hash para o objeto
	@Override
	public int hashCode() {
		return super.hashCode();
	}

	// Método para comparar se dois objetos Dolar são iguais
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
	
    
}

