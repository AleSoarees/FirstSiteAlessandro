package monetario;
 
 import java.util.Objects;
 
 public abstract class Moeda {
 	protected double valor;
 	protected String tipo;
 	
 	//valor e tipo que a moeda representa
  
 	protected Moeda(double valor, String tipo) {
 		this.valor = valor;
 		this.tipo = tipo;
 	}
 
   // Pega o valor atual da moeda
 	public double getValor() {
 		return valor;
 	}
 	
   // Atualiza o valor da moeda
 
 	public void setValor(double valor) {
 		this.valor = valor;
 	} 
 	
 	
 	// Método que todas as moedas precisam implementar
 
 	abstract double converter();
 	
 	public void info() {
 		System.out.println("---------------");
 		System.out.println("Moeda: " + tipo);
         System.out.println("Valor: " + getValor());
         System.out.println("---------------");
 	}
 	
 	//Ele mostra as opções de moedas disponíveis no sistema
 	
 	public static void menuMoeda() {
 		System.out.println("Digite a moeda: ");
         System.out.println("1 - Dólar");
         System.out.println("2 - Euro");
         System.out.println("3 - Real");
 	}
 
 	
 	// Gera um código único para a moeda, baseado no seu tipo e valor
 	@Override
 	public int hashCode() {
 		return Objects.hash(tipo, valor);
 	}
 
 	
 	//Compara se duas moedas são iguais.
 	@Override
 	public boolean equals(Object obj) {
 		if (this == obj)
 			return true;
 		if (obj == null)
 			return false;
 		if (getClass() != obj.getClass())
 			return false;
 		Moeda other = (Moeda) obj;
 		return Objects.equals(tipo, other.tipo)
 				&& Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
 	}
 	
 	
 }